var points = [];
// var mult[iplier] controls he angle speed / can be altered to generate random alterations of flow fields
var mult = 0.005;

function setup() {
  createCanvas(windowWidth, windowHeight);
  //background has been moved into setup function to avoid drawing it multiple times
  background(30);
  // angle mode set to degrees
  angleMode(DEGREES);
  noiseDetail(1);
  // density variable control the amount of points in the flow field 
  var density = 5;
  // space controlls the distance between each point
  var space = width / density;
  
  // for loop which creates a starting point for all flow 'points'
    for (var x = 0; x < width; x += space) {
         // space variable is called in te for loops
        for (var y = 0; y , height; y += space) {
          // creating a vector for each x and y coordinate
            var p = createVector(x + random(-10,10), y + random(-10, 10));
            // this vector is added to the points array in line 1
            points.push(p);
        } 
    }
}

function draw() {
  // removes stroke
    noStroke();
  // fills as white colour
    //fill(255);
  
  // creates another for loop to interate through the points
  for (var i = 0; i < points.length; i++) {
    // adding colours to the flow field with random values assigned according to the points variable
    var r = map(points[i].x, 0, width, 50, 255)
    var g = map(points[i].x, 0, height, 50, 255)
    var b = map(points[i].x, 0, width, 255, 50)
    
    //creating a noise function to simulate an angle at which each point will move
    var angle = map(noise(points[i].x * mult, points[i],y * mult), 0, 1, 0, 720);
    // adds a vector to each point based on the angle
    points[i].add(createVector(cos(angle), sin(angle)));
    
    
    // creates a circle at the x and y coordinate of each point
    ellipse(points[i].x, points[i].y);
    
  }
  
}